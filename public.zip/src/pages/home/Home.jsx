import React from "react";

const Home = () => {
  return <h1>Welcome to Mail Delivery Service</h1>;
};

export default Home;
